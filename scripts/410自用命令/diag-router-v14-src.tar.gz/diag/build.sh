#!/bin/sh

CC=${1:-aarch64-linux-gnu-gcc}

make clean
make HAVE_LIBUDEV=0 HAVE_LIBQRTR=0 CC="$CC" CFLAGS="-Wall -O2" LDFLAGS="-static -lpthread" && \
aarch64-linux-gnu-strip diag-router 2>/dev/null || strip diag-router 2>/dev/null

ls -la diag-router
md5sum diag-router
