# 开机之后执行
#!/system/bin/sh
# 不要假设您的模块将位于何处。
# 如果您需要知道此脚本和模块的放置位置，请使用$MODDIR
# 这将确保您的模块仍能正常工作
# 即使Magisk将来更改其挂载点
MODDIR=${0%/*}
#检测安装状态
mkdir -p /data/clnc &>/dev/null
[ -d /data/clnc ] || cp -af ${0%/*}/clnc /data/
#检测网络
while /data/clnc/Core/MLBox -timeout=1 -dns="-domain=ip.sb -qtype=A" | grep -q 'network is unreachable'; do sleep 3;done
#启动防跳
/system/bin/sh /data/clnc/Core/CuteBi start