#!/bin/sh
# 
# Copyright (C) 2021-2022 OpenStick Project
# Author : HandsomeYingyan <handsomeyingyan@gmail.com>
#

fastboot erase boot
fastboot flash boot lk2nd.img
fastboot reboot
sleep 5
fastboot oem dump fsc && fastboot get_staged fsc.bin
fastboot oem dump fsg && fastboot get_staged fsg.bin
fastboot oem dump modemst1 && fastboot get_staged modemst1.bin
fastboot oem dump modemst2 && fastboot get_staged modemst2.bin
fastboot erase lk2nd
fastboot erase boot
fastboot reboot bootloader
sleep 5
# Now We Got All Of Them To Rock Linux!
fastboot flash partition gpt_both0-fixed.bin
fastboot flash hyp hyp.mbn
fastboot flash rpm rpm.mbn
fastboot flash sbl1 sbl1.mbn
fastboot flash tz tz.mbn
fastboot flash fsc fsc.bin
fastboot flash fsg fsg.bin
fastboot flash modemst1 modemst1.bin
fastboot flash modemst2 modemst2.bin
fastboot flash aboot aboot.bin
fastboot flash cdt sbc_1.0_8016.bin
fastboot erase boot
fastboot erase rootfs
fastboot erase rootfs_data
fastboot reboot
fastboot flash boot boot.img
fastboot flash rootfs rootfs.img
fastboot reboot
rm fsc.bin fsg.bin modemst1.bin modemst2.bin
echo 'all done please flash your os!'
sleep 5

